from flask import Flask, render_template, request, jsonify
from datetime import datetime

app = Flask(__name__)

# ── Library Knowledge Base ──────────────────────────────────────────────────

LIBRARY_DATA = {
    "opening_hours": {
        "monday":    "9:00 AM – 8:00 PM",
        "tuesday":   "9:00 AM – 8:00 PM",
        "wednesday": "9:00 AM – 8:00 PM",
        "thursday":  "9:00 AM – 8:00 PM",
        "friday":    "9:00 AM – 6:00 PM",
        "saturday":  "10:00 AM – 5:00 PM",
        "sunday":    "Closed",
    },
    "books": {
        "the great gatsby": {
            "author": "F. Scott Fitzgerald",
            "available": True,
            "copies": 3,
            "location": "Fiction – Shelf A4",
        },
        "to kill a mockingbird": {
            "author": "Harper Lee",
            "available": False,
            "due_date": "2025-05-10",
            "copies": 2,
            "location": "Fiction – Shelf B2",
        },
        "1984": {
            "author": "George Orwell",
            "available": True,
            "copies": 5,
            "location": "Fiction – Shelf A1",
        },
        "sapiens": {
            "author": "Yuval Noah Harari",
            "available": True,
            "copies": 2,
            "location": "Non-Fiction – Shelf C3",
        },
        "harry potter": {
            "author": "J.K. Rowling",
            "available": False,
            "due_date": "2025-05-03",
            "copies": 4,
            "location": "Fiction – Shelf D1",
        },
        "the alchemist": {
            "author": "Paulo Coelho",
            "available": True,
            "copies": 3,
            "location": "Fiction – Shelf B5",
        },
        "brief history of time": {
            "author": "Stephen Hawking",
            "available": True,
            "copies": 1,
            "location": "Science – Shelf E2",
        },
        "atomic habits": {
            "author": "James Clear",
            "available": False,
            "due_date": "2025-05-15",
            "copies": 2,
            "location": "Self-Help – Shelf F1",
        },
    },
}

# ── Intent Detection & Response ─────────────────────────────────────────────

def detect_intent(message: str) -> str:
    msg = message.lower()
    if any(w in msg for w in ["hour", "open", "close", "timing", "time", "when"]):
        return "hours"
    if any(w in msg for w in ["due", "return", "deadline", "when is"]):
        return "due_date"
    if any(w in msg for w in ["find", "available", "borrow", "search", "do you have", "book", "look for"]):
        return "find_book"
    if any(w in msg for w in ["hello", "hi", "hey", "greet"]):
        return "greet"
    if any(w in msg for w in ["help", "what can", "assist"]):
        return "help"
    return "unknown"


def get_today_hours() -> str:
    day = datetime.now().strftime("%A").lower()
    return LIBRARY_DATA["opening_hours"].get(day, "Unknown")


def search_book(message: str):
    msg = message.lower()
    for title, info in LIBRARY_DATA["books"].items():
        if title in msg or any(word in msg for word in title.split() if len(word) > 3):
            return title, info
    return None, None


def build_response(message: str) -> str:
    intent = detect_intent(message)

    if intent == "greet":
        return (
            "👋 Hello! Welcome to the Library Assistant Bot. "
            "I can help you with:\n"
            "• 📚 Finding books\n"
            "• 📅 Checking due dates\n"
            "• 🕐 Opening hours\n\n"
            "What would you like to know?"
        )

    if intent == "help":
        return (
            "I can assist you with:\n\n"
            "📚 <b>Finding Books</b> — Ask me to search for any book\n"
            "📅 <b>Due Dates</b> — Ask when a borrowed book is due back\n"
            "🕐 <b>Opening Hours</b> — Ask about library timings\n\n"
            "Just type your question naturally!"
        )

    if intent == "hours":
        msg = message.lower()
        hours_text = ""

        # Check if a specific day is mentioned
        for day in LIBRARY_DATA["opening_hours"]:
            if day in msg:
                hours = LIBRARY_DATA["opening_hours"][day]
                return f"🕐 <b>{day.capitalize()}</b>: {hours}"

        # Today's hours
        today = datetime.now().strftime("%A").lower()
        today_hours = LIBRARY_DATA["opening_hours"][today]
        all_hours = "\n".join(
            f"• {d.capitalize()}: {h}" for d, h in LIBRARY_DATA["opening_hours"].items()
        )
        return (
            f"🕐 <b>Today ({today.capitalize()})</b>: {today_hours}\n\n"
            f"<b>Full Weekly Schedule:</b>\n{all_hours}"
        )

    if intent in ("find_book", "due_date"):
        title, info = search_book(message)
        if title and info:
            if info["available"]:
                return (
                    f"✅ <b>{title.title()}</b> by {info['author']}\n\n"
                    f"• Status: Available ({info['copies']} copies)\n"
                    f"• Location: {info['location']}"
                )
            else:
                return (
                    f"📖 <b>{title.title()}</b> by {info['author']}\n\n"
                    f"• Status: Currently Borrowed\n"
                    f"• Due Back: {info.get('due_date', 'Unknown')}\n"
                    f"• Total Copies: {info['copies']}\n"
                    f"• Location: {info['location']}\n\n"
                    f"Would you like me to note your interest?"
                )
        else:
            return (
                "🔍 I couldn't find that book in our system.\n\n"
                "Books I can look up include:\n"
                + "\n".join(f"• {t.title()}" for t in LIBRARY_DATA["books"])
                + "\n\nTry searching by title!"
            )

    return (
        "🤔 I'm not sure I understood that. I can help with:\n"
        "• Finding books\n"
        "• Checking due dates\n"
        "• Opening hours\n\n"
        "Try asking something like: <i>'Is 1984 available?'</i> or <i>'What are your opening hours?'</i>"
    )


# ── Routes ──────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "").strip()
    if not user_message:
        return jsonify({"response": "Please type a message."})
    response = build_response(user_message)
    return jsonify({"response": response})


if __name__ == "__main__":
    app.run(debug=True)