# Lab Task 1 — HadithBot + Library Assistant Bot
## Setup & Run Instructions

### Install dependencies
```bash
pip install sentence-transformers faiss-cpu flask numpy pandas scikit-learn
```

---

## Task 1A — Run HadithBot.ipynb
```bash
jupyter notebook HadithBot.ipynb
```
Run all cells top to bottom. The last cell lets you type a question interactively.

---

## Task 1B — Library Assistant Bot (Flask App)

### Project Structure
```
library_bot/
├── app.py            ← Flask app (main entry point)
├── library_data.py   ← 27 Q&A pairs dataset
├── embedder.py       ← MiniLM / TF-IDF encoder wrapper
└── templates/
    └── index.html    ← Web UI
```

### Run the app
```bash
cd library_bot
python app.py
```
Then open **http://127.0.0.1:5000** in your browser.

---

## Pipeline Summary

| Step | Component        | Tool/Library                          |
|------|------------------|---------------------------------------|
| 1    | Dataset          | 27 Library Q&A pairs (custom)         |
| 2    | Preprocessing    | Lowercase + whitespace normalisation  |
| 3    | Embedding        | HuggingFace `all-MiniLM-L6-v2`        |
| 4    | Vector Store     | FAISS `IndexFlatIP` (cosine sim)      |
| 5    | Search           | Top-3 similarity retrieval            |
| 6    | UI               | Flask + plain HTML/CSS/JS             |

> **Note:** If HuggingFace is unreachable (offline / restricted network),
> the embedder automatically falls back to sklearn TF-IDF. The rest of the
> pipeline (FAISS, Flask, UI) is identical either way.

---

## Topics Covered in Library Bot Dataset
- Borrowing & returning books
- Loan periods & renewals
- Overdue fines
- Membership registration & fees
- Finding books (OPAC, Dewey Decimal)
- Digital resources & e-books
- Study rooms & WiFi
- Printing & scanning
- Research help & citation (APA)
- Children's section & reading programs
- Urdu language collection
- Book donations
