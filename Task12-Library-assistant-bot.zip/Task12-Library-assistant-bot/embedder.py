"""
embedder.py — Embedding wrapper
  • Tries to load HuggingFace all-MiniLM-L6-v2 first (best quality).
  • Falls back to a TF-IDF vectoriser if HuggingFace is unreachable
    (e.g. restricted network / offline environment).
Both expose the same encode(texts) → numpy array interface.
"""

import numpy as np

_model = None
_mode  = None   # "minilm" | "tfidf"

# ──────────────────────────────────────────────
class _TFIDFEncoder:
    """Lightweight sklearn TF-IDF encoder that mimics SentenceTransformer API."""
    def __init__(self):
        from sklearn.feature_extraction.text import TfidfVectorizer
        self.vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)
        self._fitted = False

    def fit(self, corpus):
        self.vec.fit(corpus)
        self._fitted = True

    def encode(self, texts, convert_to_numpy=True, show_progress_bar=False):
        if not self._fitted:
            raise RuntimeError("Call fit() first.")
        mat = self.vec.transform(texts).toarray().astype(np.float32)
        return mat


def load_encoder(corpus=None):
    """
    Returns (encoder, mode_string).
    corpus is required when using TF-IDF fallback (for fitting the vocabulary).
    """
    global _model, _mode

    if _model is not None:
        return _model, _mode

    # 1. Try MiniLM
    try:
        from sentence_transformers import SentenceTransformer
        m = SentenceTransformer("all-MiniLM-L6-v2")
        # quick probe
        m.encode(["test"], convert_to_numpy=True)
        _model, _mode = m, "minilm"
        print("[Embedder] ✅ Using all-MiniLM-L6-v2 (HuggingFace)")
        return _model, _mode
    except Exception as e:
        print(f"[Embedder] ⚠️  MiniLM unavailable ({type(e).__name__}). Falling back to TF-IDF.")

    # 2. TF-IDF fallback
    enc = _TFIDFEncoder()
    if corpus:
        enc.fit(corpus)
    _model, _mode = enc, "tfidf"
    print("[Embedder] ✅ Using TF-IDF (sklearn) — offline mode")
    return _model, _mode
