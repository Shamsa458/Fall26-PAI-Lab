"""
Library Assistant Bot — QnA Dataset
Topic: Library services, books, borrowing, research, reading.
"""

LIBRARY_QNA = [
    # --- Borrowing & Returns ---
    {
        "question": "How do I borrow a book from the library?",
        "answer": "To borrow a book, bring your library membership card to the circulation desk, select the book you want, and the librarian will check it out to you. You can also use our self-checkout kiosks. Make sure your account is active and has no overdue fines exceeding the limit."
    },
    {
        "question": "How many books can I borrow at once?",
        "answer": "Standard members can borrow up to 5 books at a time. Premium members can borrow up to 10 books. Students with a valid university ID can borrow up to 8 books simultaneously."
    },
    {
        "question": "How long can I keep a borrowed book?",
        "answer": "Books can be borrowed for 14 days (2 weeks). Reference books and new arrivals may only be borrowed for 7 days. You can renew a book twice online or at the desk, as long as no one else has reserved it."
    },
    {
        "question": "How do I return a book to the library?",
        "answer": "Return books at the main circulation desk during opening hours, or use our 24/7 book drop box located at the library entrance. Please do not leave books on tables or shelves — always return to the desk or drop box."
    },
    {
        "question": "Can I renew my borrowed books?",
        "answer": "Yes! You can renew books up to 2 times. Renew online via the library portal, call the circulation desk, or visit in person. Renewals are not allowed if another member has placed a hold on the book."
    },
    {
        "question": "What happens if I return a book late?",
        "answer": "A fine of Rs. 5 per day is charged for overdue books. If a book is more than 30 days overdue, your borrowing privileges will be suspended until the fine is paid. Lost books must be replaced or a replacement cost will be charged."
    },

    # --- Membership ---
    {
        "question": "How do I get a library membership card?",
        "answer": "Visit the library registration desk with a valid ID (CNIC, student card, or passport), one passport-sized photo, and the annual membership fee. Membership is free for enrolled university students with a valid university ID."
    },
    {
        "question": "What are the library membership fees?",
        "answer": "Annual membership costs Rs. 500 for adults, Rs. 200 for students (with valid ID), and Rs. 100 for children under 16. Senior citizens (60+) get free membership. Premium membership with extended borrowing costs Rs. 1,000/year."
    },
    {
        "question": "Can I renew my library membership?",
        "answer": "Yes, memberships are renewed annually. You can renew online through the library portal, via phone, or in person. You'll receive a reminder email 30 days before your membership expires."
    },

    # --- Finding Books & Resources ---
    {
        "question": "How do I find a specific book in the library?",
        "answer": "Use our Online Public Access Catalog (OPAC) available at library terminals or on the library website. Search by title, author, ISBN, or subject. The catalog shows the book's location (floor, shelf number) and availability status."
    },
    {
        "question": "What is the Dewey Decimal System?",
        "answer": "The Dewey Decimal Classification System organizes books by subject using numbers. For example: 000-099 = Computer Science & General Works, 100-199 = Philosophy, 200-299 = Religion, 300-399 = Social Sciences, 400-499 = Language, 500-599 = Natural Sciences, 600-699 = Technology, 700-799 = Arts, 800-899 = Literature, 900-999 = History & Geography."
    },
    {
        "question": "How do I search for books by a specific author?",
        "answer": "In the OPAC catalog, choose 'Author' from the search dropdown and type the author's last name followed by first name (e.g., 'Hosseini, Khaled'). Results will show all books by that author available in our collection."
    },
    {
        "question": "Does the library have e-books or digital resources?",
        "answer": "Yes! We provide access to thousands of e-books through platforms like EBSCO, ProQuest, and Springer. Log in with your library card number on the library website. Digital resources are available 24/7 from any device."
    },
    {
        "question": "Can I reserve a book that is currently checked out?",
        "answer": "Yes, you can place a hold/reservation on any book that is currently borrowed. Log into the library portal, find the book, and click 'Place Hold.' You will be notified by email or SMS when the book is returned and ready for pickup. Holds are kept for 3 days."
    },

    # --- Library Services ---
    {
        "question": "Does the library have printing and scanning services?",
        "answer": "Yes, we offer printing (black & white and colour), photocopying, and scanning services at the resource centre on the ground floor. Printing costs Rs. 5 per black & white page and Rs. 20 per colour page. Scanning is free."
    },
    {
        "question": "Is there WiFi available in the library?",
        "answer": "Yes, free WiFi is available throughout the library. Connect to the network 'LibraryFree' and log in with your library card number. WiFi is available during library hours. The network supports speeds up to 50 Mbps."
    },
    {
        "question": "Does the library have study rooms?",
        "answer": "Yes, we have 12 private study rooms and 4 group discussion rooms available for booking. Reserve a room online or at the front desk. Individual study rooms can be booked for up to 2 hours per day; group rooms for up to 4 hours."
    },
    {
        "question": "Can I bring food and drinks into the library?",
        "answer": "Light snacks and water bottles with lids are permitted in designated areas only. No hot food or open drinks near computers or book shelves. There is a café on the ground floor open 8 AM–6 PM for meals and beverages."
    },
    {
        "question": "What are the library opening hours?",
        "answer": "The library is open Monday to Friday: 8:00 AM – 9:00 PM, Saturday: 9:00 AM – 6:00 PM, Sunday: 10:00 AM – 4:00 PM. The library is closed on public holidays. Extended hours are available during exam seasons."
    },

    # --- Research Help ---
    {
        "question": "Can the library help me with my research project?",
        "answer": "Absolutely! Our reference librarians are trained research specialists. Visit the Reference Desk or book a one-on-one Research Consultation appointment. We help with finding credible sources, citation management (Zotero, Mendeley), and structuring literature reviews."
    },
    {
        "question": "How do I cite books in APA format?",
        "answer": "APA book citation format: Author, A. A. (Year). Title of work: Capital letter also for subtitle. Publisher. Example: Hosseini, K. (2003). The Kite Runner. Riverhead Books. For edited books add (Ed.) after the editor's name."
    },
    {
        "question": "What databases does the library provide access to?",
        "answer": "The library provides access to: JSTOR (academic journals), IEEE Xplore (engineering & technology), PubMed (medical sciences), Springer Link (science & tech e-books), EBSCO Academic Search Complete, ProQuest Dissertations, and HEC Digital Library (Pakistan)."
    },
    {
        "question": "How do I access HEC Digital Library?",
        "answer": "HEC Digital Library is free for all Pakistani university students. Visit hec.gov.pk/hecdl, select your university, and log in with your university email. It provides access to thousands of research journals, e-books, and theses."
    },

    # --- Children & Special Services ---
    {
        "question": "Does the library have a children's section?",
        "answer": "Yes! Our Children's Corner on the second floor has picture books, story books, educational games, and a reading area. Children's reading events and storytelling sessions are held every Saturday at 11 AM. Children under 12 must be accompanied by an adult."
    },
    {
        "question": "Does the library offer any reading programs?",
        "answer": "Yes! We run: Summer Reading Challenge (June–August), Book Club meetings (every 2nd Wednesday), Author Talk events (monthly), and a Children's Storytime (every Saturday). Check the library website or notice board for the full events calendar."
    },
    {
        "question": "Can I donate books to the library?",
        "answer": "Yes, we welcome book donations! Bring your books to the donations desk at the library entrance. We accept books in good condition published within the last 15 years. Donated books are reviewed by librarians and added to the collection or used for fundraising sales."
    },
    {
        "question": "Does the library have books in Urdu?",
        "answer": "Yes, we have a dedicated Urdu & Regional Languages section on the 2nd floor. Our collection includes Urdu fiction, poetry (Iqbal, Faiz, Ghalib), history, and religious texts. Urdu newspapers and magazines are also available in the reading room."
    },
]
