"""
Library Assistant Bot — Flask Web Application
=========================================
Pipeline:
  1. Preprocess QnA dataset (normalise text)
  2. Embed using HuggingFace MiniLM  (falls back to TF-IDF offline)
  3. Store vectors in FAISS (cosine similarity via IndexFlatIP)
  4. Similarity search on user query
  5. Serve via Flask + HTML UI
"""

import re
import numpy as np
import faiss
from flask import Flask, render_template, request, jsonify
from library_data import LIBRARY_QNA
from embedder import load_encoder

# ─────────────────────────────────────────────
# 1.  PREPROCESSING
# ─────────────────────────────────────────────
def preprocess(text: str) -> str:
    text = re.sub(r'[^A-Za-z\s]', '', text)   # remove symbols & numbers
    text = text.lower().strip()
    text = " ".join(text.split())              # remove extra whitespace
    return text

questions     = [preprocess(item["question"]) for item in LIBRARY_QNA]
answers       = [item["answer"]               for item in LIBRARY_QNA]
raw_questions = [item["question"]             for item in LIBRARY_QNA]

print(f"[INFO] Dataset: {len(questions)} Q&A pairs loaded")

# ─────────────────────────────────────────────
# 2.  EMBEDDING  (MiniLM or TF-IDF fallback)
# ─────────────────────────────────────────────
encoder, MODE = load_encoder(corpus=questions)

print("[INFO] Embedding questions...")
embeddings = encoder.encode(questions, convert_to_numpy=True).astype(np.float32)
norms      = np.linalg.norm(embeddings, axis=1, keepdims=True)
embeddings = embeddings / np.where(norms == 0, 1, norms)

# ─────────────────────────────────────────────
# 3.  VECTOR STORAGE  — FAISS IndexFlatIP
# ─────────────────────────────────────────────
DIM   = embeddings.shape[1]
index = faiss.IndexFlatIP(DIM)          # Inner-product = cosine on normalised vecs
index.add(embeddings)
print(f"[INFO] FAISS index ready  ({index.ntotal} vectors, dim={DIM}, mode={MODE})")

# ─────────────────────────────────────────────
# 4.  SEARCH FUNCTION
# ─────────────────────────────────────────────
def search(user_query: str, top_k: int = 3):
    cleaned = preprocess(user_query)
    vec = encoder.encode([cleaned], convert_to_numpy=True).astype(np.float32)
    nrm = np.linalg.norm(vec, axis=1, keepdims=True)
    vec = vec / np.where(nrm == 0, 1, nrm)
    # FAISS returns (scores, indices) arrays of shape (1, top_k)
    scores, indices = index.search(vec, top_k)
    results = []
    for rank, idx in enumerate(indices[0]):
        pct = round(float(scores[0][rank]) * 100, 1)
        results.append({
            "question": raw_questions[idx],
            "answer":   answers[idx],
            "score":    pct,
            "label":    _label(pct),
        })
    return results

def _label(pct):
    if pct >= 75: return "High"
    if pct >= 45: return "Medium"
    return "Low"

# ─────────────────────────────────────────────
# 5.  FLASK APP
# ─────────────────────────────────────────────
app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html", mode=MODE.upper())

@app.route("/ask", methods=["POST"])
def ask():
    data  = request.get_json()
    query = data.get("query", "").strip()
    if not query:
        return jsonify({"error": "Please enter a question."}), 400
    return jsonify({"query": query, "results": search(query), "mode": MODE})

@app.route("/suggestions")
def suggestions():
    return jsonify([
        "How do I borrow a book?",
        "What are the library opening hours?",
        "How many books can I borrow at once?",
        "Can I renew my library membership?",
        "Does the library have study rooms?",
        "How do I cite a book in APA format?",
        "Is there WiFi in the library?",
        "How do I find a book by its author?",
    ])

if __name__ == "__main__":
    print("\nLibrary Bot running at  http://127.0.0.1:5000\n")
    app.run(debug=True, use_reloader=False, port=5000)