import cv2

camera = cv2.VideoCapture("http://192.168.0.107:4747/video")
print("Camera opened:", camera.isOpened())

ret, frame = camera.read()
print("Frame received:", ret)

if ret:
    cv2.imwrite("test_frame.jpg", frame)
    print("Frame saved!")
else:
    print("No frame received!")