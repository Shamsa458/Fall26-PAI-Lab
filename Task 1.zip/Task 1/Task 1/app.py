import re
import time
import logging
import os
import threading
from urllib.parse import urlparse, urljoin
from collections import deque
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed
from io import BytesIO

import requests
import pandas as pd
from bs4 import BeautifulSoup
from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.utils import secure_filename

# -------------------- Logging --------------------
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger("EmailScraper")

# -------------------- Flask Setup --------------------
app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = "uploads"
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024

os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

# -------------------- Email Pattern --------------------
EMAIL_REGEX = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'


# =====================================================
#                WEB SCRAPER CLASS
# =====================================================
class EmailFinder:

    def __init__(self, timeout=10, delay=0.4, max_pages=12, workers=5):
        self.timeout = timeout
        self.delay = delay
        self.max_pages = max_pages
        self.workers = workers
        self.cache = {}
        self.lock = threading.Lock()

        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
        }

        self.priority_paths = [
            "/", "/contact", "/about", "/team",
            "/contact-us", "/about-us", "/support"
        ]

    # ---------------- URL Validation ----------------
    @lru_cache(maxsize=500)
    def valid_url(self, url):
        try:
            parsed = urlparse(url)
            return parsed.scheme in ["http", "https"] and parsed.netloc
        except:
            return False

    # ---------------- Domain Normalize ----------------
    def base_domain(self, url):
        try:
            p = urlparse(url)
            return f"{p.scheme}://{p.netloc}"
        except:
            return url

    # ---------------- Extract Emails ----------------
    def find_emails(self, text):
        if not text:
            return set()
        return set(re.findall(EMAIL_REGEX, text))

    # ---------------- Mailto Emails ----------------
    def emails_from_links(self, soup):
        emails = set()

        for link in soup.find_all("a", href=True):
            href = link.get("href", "")

            if href.startswith("mailto:"):
                email = href.replace("mailto:", "").split("?")[0]
                if re.match(EMAIL_REGEX, email):
                    emails.add(email)

        return emails

    # ---------------- Extract Internal Links ----------------
    def collect_links(self, soup, current_url):

        links = set()
        domain = self.base_domain(current_url)

        for p in self.priority_paths:
            links.add(domain + p)

        for tag in soup.find_all("a", href=True):

            href = tag.get("href")

            if not href or href.startswith(("#", "mailto:", "tel:", "javascript")):
                continue

            try:
                abs_url = urljoin(current_url, href)
            except:
                continue

            if self.base_domain(abs_url) == domain:
                parsed = urlparse(abs_url)
                clean = f"{parsed.scheme}://{parsed.netloc}{parsed.path}".rstrip("/")
                links.add(clean)

        return links

    # ---------------- Scrape Single Page ----------------
    def scrape_page(self, url):

        with self.lock:
            if url in self.cache:
                return self.cache[url]

        emails = set()
        links = set()

        try:

            response = requests.get(url, headers=self.headers, timeout=self.timeout)

            if response.status_code != 200:
                return emails, links

            soup = BeautifulSoup(response.content, "html.parser")

            for tag in soup(["script", "style"]):
                tag.decompose()

            text = soup.get_text(" ", strip=True)

            emails.update(self.find_emails(text))
            emails.update(self.emails_from_links(soup))
            links.update(self.collect_links(soup, url))

        except Exception as e:
            logger.warning(f"Error scraping {url}: {str(e)}")

        with self.lock:
            self.cache[url] = (emails, links)

        return emails, links

    # ---------------- Crawl Website ----------------
    def crawl_site(self, start_url):

        if not start_url.startswith(("http://", "https://")):
            start_url = "https://" + start_url

        visited = set()
        queue = deque([start_url])

        emails_found = set()
        pages = 0
        start_time = time.time()

        while queue and pages < self.max_pages:

            current = queue.popleft()

            if current in visited:
                continue

            visited.add(current)

            emails, links = self.scrape_page(current)

            emails_found.update(emails)
            pages += 1

            for link in links:
                if link not in visited:
                    queue.append(link)

            time.sleep(self.delay)

        total_time = time.time() - start_time

        return {
            "base_url": start_url,
            "emails": list(emails_found),
            "email_count": len(emails_found),
            "pages_crawled": pages,
            "time_taken": round(total_time, 2),
            "error": None
        }

    # ---------------- Multiple URLs ----------------
    def crawl_multiple(self, urls):

        results = []

        with ThreadPoolExecutor(max_workers=self.workers) as executor:

            tasks = {executor.submit(self.crawl_site, u): u for u in urls}

            for future in as_completed(tasks):

                try:
                    results.append(future.result())

                except Exception as e:

                    results.append({
                        "base_url": tasks[future],
                        "emails": [],
                        "email_count": 0,
                        "pages_crawled": 0,
                        "time_taken": 0,
                        "error": str(e)
                    })

        return results

    # ---------------- Save Excel ----------------
    def create_excel(self, results):

        rows = []

        for r in results:

            if r["email_count"] == 0:

                rows.append({
                    "URL": r["base_url"],
                    "Email": "Not Found",
                    "Pages": r["pages_crawled"],
                    "Time": r["time_taken"]
                })

            else:

                for e in r["emails"]:

                    rows.append({
                        "URL": r["base_url"],
                        "Email": e,
                        "Pages": r["pages_crawled"],
                        "Time": r["time_taken"]
                    })

        df = pd.DataFrame(rows)

        output = BytesIO()

        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            df.to_excel(writer, index=False)

        output.seek(0)

        return output


# Global Object
scraper = EmailFinder()


# =====================================================
#                 FLASK ROUTES
# =====================================================

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/api/upload", methods=["POST"])
def upload_file():

    if "file" not in request.files:
        return jsonify({"success": False, "error": "No file uploaded"})

    file = request.files["file"]

    filename = secure_filename(file.filename)

    try:

        if filename.endswith(".csv"):
            df = pd.read_csv(file)

        else:
            df = pd.read_excel(file)

    except:
        return jsonify({"success": False, "error": "File read error"})

    if "Urls" not in df.columns:
        return jsonify({"success": False, "error": "Column 'Urls' missing"})

    urls = df["Urls"].dropna().astype(str).tolist()

    results = scraper.crawl_multiple(urls)

    total_emails = sum(r["email_count"] for r in results)

    return jsonify({
        "success": True,
        "results": results,
        "total_urls": len(urls),
        "total_emails": total_emails
    })


@app.route("/api/download", methods=["POST"])
def download_excel():

    data = request.get_json()
    results = data.get("results", [])

    excel = scraper.create_excel(results)

    return send_file(
        excel,
        as_attachment=True,
        download_name="emails.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )


if __name__ == "__main__":
    app.run(debug=True)