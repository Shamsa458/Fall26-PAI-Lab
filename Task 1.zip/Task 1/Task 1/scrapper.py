import re
import time
import logging
import threading
from urllib.parse import urlparse, urljoin
from collections import deque
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from bs4 import BeautifulSoup
import pandas as pd


# ---------------- Logging Configuration ----------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

log = logging.getLogger("EmailCrawler")

# ---------------- Email Regex ----------------
EMAIL_REGEX = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'


# ======================================================
#                  EMAIL CRAWLER CLASS
# ======================================================

class FastEmailCrawler:

    def __init__(self, timeout=8, pause=0.3, page_limit=15, workers=5):

        self.timeout = timeout
        self.pause = pause
        self.page_limit = page_limit
        self.workers = workers

        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
        }

        self.page_cache = {}
        self.lock = threading.Lock()

        self.common_paths = [
            "/", "/contact", "/about", "/team",
            "/contact-us", "/about-us", "/support",
            "/help", "/careers"
        ]

    # ---------------- URL Validation ----------------
    @lru_cache(maxsize=800)
    def check_url(self, url):

        try:
            p = urlparse(url)
            return p.scheme in ["http", "https"] and p.netloc
        except:
            return False

    # ---------------- Domain Normalization ----------------
    def get_base(self, url):

        try:
            p = urlparse(url)
            return f"{p.scheme}://{p.netloc}"
        except:
            return url

    # ---------------- Email Extraction ----------------
    def find_emails(self, text):

        if not text:
            return set()

        return set(re.findall(EMAIL_REGEX, text))

    # ---------------- Extract Mailto Links ----------------
    def find_mailto(self, soup):

        emails = set()

        try:
            for tag in soup.find_all("a", href=True):

                href = tag.get("href", "")

                if href.startswith("mailto:"):

                    email = href.replace("mailto:", "").split("?")[0]

                    if re.match(EMAIL_REGEX, email):
                        emails.add(email)

        except:
            pass

        return emails

    # ---------------- Extract Internal Links ----------------
    def collect_internal_links(self, soup, current_url):

        links = set()
        base = self.get_base(current_url)

        try:

            for p in self.common_paths:
                links.add(base + p)

            for tag in soup.find_all("a", href=True):

                href = tag.get("href", "").strip()

                if not href or href.startswith(("#", "javascript:", "mailto:", "tel:")):
                    continue

                try:
                    abs_url = urljoin(current_url, href)
                except:
                    continue

                if self.get_base(abs_url) == base:

                    parsed = urlparse(abs_url)
                    clean = f"{parsed.scheme}://{parsed.netloc}{parsed.path}".rstrip("/")

                    links.add(clean)

        except:
            pass

        return links

    # ---------------- Scrape One Page ----------------
    def scrape_page(self, url):

        with self.lock:
            if url in self.page_cache:
                return self.page_cache[url]

        emails = set()
        links = set()

        try:

            response = requests.get(url, headers=self.headers, timeout=self.timeout)

            if response.status_code != 200:
                return emails, links

            soup = BeautifulSoup(response.content, "html.parser")

            for tag in soup(["script", "style", "noscript"]):
                tag.decompose()

            text = soup.get_text(" ", strip=True)

            emails.update(self.find_emails(text))
            emails.update(self.find_mailto(soup))
            links.update(self.collect_internal_links(soup, url))

        except Exception as e:
            log.debug(f"Page error {url} : {str(e)}")

        with self.lock:
            self.page_cache[url] = (emails, links)

        return emails, links

    # ---------------- Crawl Website ----------------
    def crawl_site(self, start_url):

        log.info(f"Start crawling: {start_url}")

        if not start_url.startswith(("http://", "https://")):
            start_url = "https://" + start_url

        if not self.check_url(start_url):

            return {
                "base_url": start_url,
                "emails": [],
                "pages_crawled": 0,
                "email_count": 0,
                "time_taken": 0,
                "error": "Invalid URL"
            }

        visited = set()
        queue = deque([start_url])

        emails_found = set()
        pages = 0

        start_time = time.time()

        while queue and pages < self.page_limit:

            url = queue.popleft()

            if url in visited:
                continue

            visited.add(url)

            log.info(f"[{pages+1}/{self.page_limit}] {url}")

            emails, links = self.scrape_page(url)

            emails_found.update(emails)

            pages += 1

            if len(emails_found) > 50:
                break

            for link in links:

                if link not in visited:
                    queue.append(link)

            time.sleep(self.pause)

        elapsed = time.time() - start_time

        return {
            "base_url": start_url,
            "emails": sorted(list(emails_found)),
            "pages_crawled": pages,
            "email_count": len(emails_found),
            "time_taken": elapsed,
            "error": None
        }

    # ---------------- Parallel Scraping ----------------
    def crawl_many(self, urls):

        results = []

        log.info(f"Processing {len(urls)} websites using {self.workers} threads")

        with ThreadPoolExecutor(max_workers=self.workers) as executor:

            tasks = {executor.submit(self.crawl_site, u): u for u in urls}

            for future in as_completed(tasks):

                try:
                    results.append(future.result())

                except Exception as e:

                    url = tasks[future]

                    results.append({
                        "base_url": url,
                        "emails": [],
                        "pages_crawled": 0,
                        "email_count": 0,
                        "time_taken": 0,
                        "error": str(e)
                    })

        return results

    # ---------------- Save Excel ----------------
    def export_excel(self, results, filename="emails_output.xlsx"):

        rows = []

        for r in results:

            if r["error"]:

                rows.append({
                    "Company URL": r["base_url"],
                    "Email": f"Error: {r['error']}",
                    "Status": "Failed",
                    "Pages": 0,
                    "Time": r["time_taken"]
                })

            elif r["email_count"] == 0:

                rows.append({
                    "Company URL": r["base_url"],
                    "Email": "No emails found",
                    "Status": "No Result",
                    "Pages": r["pages_crawled"],
                    "Time": r["time_taken"]
                })

            else:

                for e in r["emails"]:

                    rows.append({
                        "Company URL": r["base_url"],
                        "Email": e,
                        "Status": "Success",
                        "Pages": r["pages_crawled"],
                        "Time": round(r["time_taken"], 2)
                    })

        df = pd.DataFrame(rows)

        with pd.ExcelWriter(filename, engine="openpyxl") as writer:

            df.to_excel(writer, index=False, sheet_name="Results")

            ws = writer.sheets["Results"]

            ws.column_dimensions["A"].width = 40
            ws.column_dimensions["B"].width = 35

        log.info(f"Excel saved: {filename}")

        return filename


# ======================================================
#              MAIN HELPER FUNCTION
# ======================================================

def run_scraper(input_file, output_file="scraped_emails2.xlsx", workers=5, pages=15):

    try:

        print(f"Loading file: {input_file}")

        df = pd.read_excel(input_file)

        if "Urls" not in df.columns:
            print("Excel must contain 'Urls' column")
            return

        urls = df["Urls"].dropna().astype(str).tolist()

        print(f"{len(urls)} URLs loaded\n")

        crawler = FastEmailCrawler(
            timeout=8,
            pause=0.3,
            page_limit=pages,
            workers=workers
        )

        start = time.time()

        results = crawler.crawl_many(urls)

        total_time = time.time() - start

        crawler.export_excel(results, output_file)

        total_emails = sum(r["email_count"] for r in results if not r["error"])

        print("\nFINAL SUMMARY")
        print("----------------------")
        print("Total URLs:", len(urls))
        print("Total Emails:", total_emails)
        print("Total Time:", round(total_time, 2), "seconds")
        print("Output File:", output_file)

    except FileNotFoundError:
        print("Input file not found")

    except Exception as e:
        print("Error:", str(e))


# ======================================================
#                   RUN PROGRAM
# ======================================================

if __name__ == "__main__":

    run_scraper(
        input_file="tech_urls.xlsx",
        output_file="scraped_emails2.xlsx",
        workers=5,
        pages=25
    )