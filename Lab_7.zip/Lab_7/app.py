import requests
from flask import Flask

app = Flask(__name__)

@app.route("/mydata")
def fetch_nasa_data():
    api_key = "ry94btUNgDqpQcKnisuRywcifOgvwE0oErtALyqZ"
    url = f"https://api.nasa.gov/neo/rest/v1/feed?start_date=2015-09-07&end_date=2015-09-08&api_key={api_key}"
    
    response = requests.get(url)
    
    if response.status_code == 200:
        nasa_data = response.json()
        dates = list(nasa_data['near_earth_objects'].keys())
        return f"<h1>Working!</h1><p>Dates: {dates}</p>"
    else:
        return f"<h1>Failed: {response.status_code}</h1>"

if __name__ == "__main__":
    app.run(debug=True)